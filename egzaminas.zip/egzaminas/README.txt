Žinoma problema, jog jei žodžiai eina tokia tvarka, kaip nurodyta sąlygoje kryžiažodis neišsprendžiamas.
Tačiau sudėjus tvarka, kaip yra dabar faile, viskas gaunasi gerai.
EDIT:
Bandyta sutvarkyti su rikiavimu, tačiau neišeina..