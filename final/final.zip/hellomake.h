/*
Vytautas Krupavičius
LSP: 2110582
Užduotis 3, variantas 10
*/

void Moves_the_line(size_t num_lines, char **lines);
void Output(size_t num_lines, char **lines);